<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'your_username');
define('DB_PASSWORD', 'your_password');
define('DB_NAME', 'your_database');
define('DB_ASSET_NAME', 'your_database');

define('REMOTEADMIN_HTTPAUTHUSERNAME', 'opensim');
define('REMOTEADMIN_HTTPAUTHPASSWORD', 'opensim123');
?>