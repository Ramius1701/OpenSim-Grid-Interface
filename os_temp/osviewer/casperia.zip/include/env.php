<?php
// Database Configuration
// Datenbank-Konfiguration
define('DB_SERVER', 'localhost:3307');
define('DB_USERNAME', 'casperia');
define('DB_PASSWORD', 'D7pibxuXXdOrk8sp');
define('DB_NAME', 'casperia');
define('DB_ASSET_NAME', 'casperia');

// RemoteAdmin Configuration
// RemoteAdmin-Konfiguration
define('REMOTEADMIN_HTTPAUTHUSERNAME', 'opensim');
define('REMOTEADMIN_HTTPAUTHPASSWORD', 'opensim123');

// Security Notice:
// Sicherheitshinweis:
// IMPORTANT: Change these default values for production use!
// WICHTIG: Ändern Sie diese Standardwerte für den Produktionseinsatz!
?>