<?php
$DB_HOST = "localhost:3307";
$DB_USER = "casperia";
$DB_PASSWORD = "D7pibxuXXdOrk8sp";
$DB_NAME = "casperia";
?>
