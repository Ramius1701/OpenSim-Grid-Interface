landtool.php funktioniert bitte in der Datei landtool.php die MySQL Daten einfügen.

currency.php funktioniert noch nicht. currency.log zeigt jetzt alle funktionsaufrufe mit übergabewerten an.

TODO:

Geld wird nicht übergeben.
